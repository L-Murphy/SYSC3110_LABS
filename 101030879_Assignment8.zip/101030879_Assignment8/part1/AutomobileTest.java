
public class AutomobileTest {
	public void race() {
		Automobile car1 = new Automobile();
		car1.setMake("Austin Healy");
		car1.model = "Sprite";
		//...
	}
}
