
public class MethodSigExample {
	   public int test(String s, int i)
	   {
	      int x = i + s.length();
	      return x;
	   }
}
